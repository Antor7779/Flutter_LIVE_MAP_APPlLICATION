import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'maps/core/themes/app_theme.dart';
import 'maps/providers/tracking_provider.dart';
import 'maps/screens/tracking_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const LocationTrackerApp());
}

class LocationTrackerApp extends StatelessWidget {
  const LocationTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<TrackingProvider>(
          create: (_) => TrackingProvider(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,

        title: 'Location Tracker',

        // Theme configuration
        theme: AppTheme.lightTheme(),
        darkTheme: AppTheme.darkTheme(),
        themeMode: ThemeMode.system,

        // Initial screen
        home: const TrackingScreen(),

        // Future routes
        routes: {
          '/tracking': (_) => const TrackingScreen(),
        },
      ),
    );
  }
}