
import 'dart:async';

import 'package:geolocator/geolocator.dart';

import '../core/constants/map_constants.dart';
import '../models/location_record.dart';

/// Service responsible for interacting directly with GPS.
///
/// Responsibilities:
/// - Get the current location
/// - Provide a real-time location stream
/// - Convert Position objects into LocationRecord objects
/// - Calculate distances between two points
class LocationService {
LocationService();

/// Returns the device's current location.
Future<LocationRecord> getCurrentLocation() async {
final position =
await Geolocator.getCurrentPosition(
desiredAccuracy: LocationAccuracy.high,
);

return _positionToRecord(position);
}

/// Returns a stream of live location updates.
Stream<LocationRecord> getLocationStream() {
return Geolocator.getPositionStream(
locationSettings: LocationSettings(
accuracy: LocationAccuracy.high,
distanceFilter:
MapConstants.distanceFilter,
),
).map(_positionToRecord);
}

/// Starts listening to live tracking updates.
///
/// Returns a subscription so callers can cancel it.
StreamSubscription<LocationRecord>
startTracking({
required Function(LocationRecord)
onLocationUpdate,
Function(Object error)? onError,
}) {
return getLocationStream().listen(
onLocationUpdate,
onError: onError,
);
}

/// Stops an existing tracking subscription.
Future<void> stopTracking(
StreamSubscription<LocationRecord>
subscription,
) async {
await subscription.cancel();
}

/// Converts Position into LocationRecord.
LocationRecord _positionToRecord(
Position position,
) {
return LocationRecord(
latitude: position.latitude,
longitude: position.longitude,
accuracy: position.accuracy,
speed: position.speed,
heading: position.heading,
altitude: position.altitude,
timestamp:
position.timestamp ??
DateTime.now(),
);
}

/// Calculates the distance between two locations in meters.
double calculateDistance(
LocationRecord start,
LocationRecord end,
) {
return Geolocator.distanceBetween(
start.latitude,
start.longitude,
end.latitude,
end.longitude,
);
}

/// Calculates total distance traveled from a list of records.
double calculateTotalDistance(
List<LocationRecord> records,
) {
if (records.length < 2) {
return 0;
}

double totalDistance = 0;

for (int i = 1;
i < records.length;
i++) {
totalDistance += calculateDistance(
records[i - 1],
records[i],
);
}

return totalDistance;
}

/// Calculates average speed in km/h.
double calculateAverageSpeed(
List<LocationRecord> records,
) {
if (records.isEmpty) {
return 0;
}

final totalSpeed = records.fold<double>(
0,
(
previousValue,
element,
) =>
previousValue +
element.speedInKmH,
);

return totalSpeed / records.length;
}

/// Returns tracking duration.
Duration calculateTrackingDuration(
List<LocationRecord> records,
) {
if (records.length < 2) {
return Duration.zero;
}

return records.last.timestamp
    .difference(
records.first.timestamp,
);
}

/// Returns the highest speed reached in km/h.
double calculateMaxSpeed(
List<LocationRecord> records,
) {
if (records.isEmpty) {
return 0;
}

double maxSpeed = 0;

for (final record in records) {
if (record.speedInKmH >
maxSpeed) {
maxSpeed =
record.speedInKmH;
}
}

return maxSpeed;
}

/// Returns whether a location is considered accurate.
bool isLocationAccurate(
LocationRecord record,
) {
return record.accuracy <=
MapConstants.targetAccuracyMeters;
}

/// Returns whether a user is moving.
bool isMoving(
LocationRecord record,
) {
return MapConstants.isMoving(
record.speedInKmH,
);
}

/// Returns movement classification.
String movementType(
LocationRecord record,
) {
return MapConstants.movementType(
record.speedInKmH,
);
}

/// Cleanup resources.
Future<void> dispose() async {
// Nothing to dispose currently.
}
}

