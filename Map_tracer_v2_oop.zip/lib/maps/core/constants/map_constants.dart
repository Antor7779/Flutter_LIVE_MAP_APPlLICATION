import 'package:flutter/material.dart';

/// Centralized configuration values used throughout
/// the tracking and map features.
///
/// Keeping these values here avoids hard-coded
/// "magic numbers" scattered across the project.
class MapConstants {
  MapConstants._();

  // ---------------------------------------------------------------------------
  // Map Zoom Configuration
  // ---------------------------------------------------------------------------

  /// Default zoom level when the map is first displayed.
  static const double defaultZoom = 17.0;

  /// Zoom level used when automatically following the user.
  static const double followZoom = 18.0;

  /// Minimum zoom level allowed.
  static const double minZoom = 3.0;

  /// Maximum zoom level allowed.
  static const double maxZoom = 19.0;

  // ---------------------------------------------------------------------------
  // GPS Tracking Configuration
  // ---------------------------------------------------------------------------

  /// Minimum distance (meters) before a new location update is emitted.
  ///
  /// Lower values increase accuracy but consume more battery.
  static const int distanceFilter = 5;

  /// Desired GPS accuracy in meters.
  ///
  /// Used as a reference value when displaying status.
  static const double targetAccuracyMeters = 10.0;

  /// Time interval between updates (seconds).
  ///
  /// Useful when later implementing timed polling.
  static const int updateIntervalSeconds = 5;

  // ---------------------------------------------------------------------------
  // Route / Polyline Configuration
  // ---------------------------------------------------------------------------

  /// Width of the route trail line.
  static const double routeStrokeWidth = 5.0;

  /// Maximum number of route points to keep in memory.
  ///
  /// Prevents excessive memory usage during long tracking sessions.
  static const int maxRoutePoints = 10000;

  // ---------------------------------------------------------------------------
  // Marker Configuration
  // ---------------------------------------------------------------------------

  /// Size of the user's location marker.
  static const double markerSize = 60.0;

  /// Radius of the outer accuracy indicator.
  static const double markerOuterRadius = 24.0;

  /// Radius of the inner location indicator.
  static const double markerInnerRadius = 10.0;

  /// Border thickness of the marker.
  static const double markerBorderWidth = 3.0;

  // ---------------------------------------------------------------------------
  // Animation Configuration
  // ---------------------------------------------------------------------------

  /// Duration for map camera animations.
  static const Duration cameraAnimationDuration =
  Duration(milliseconds: 600);

  /// Duration used for general UI transitions.
  static const Duration uiAnimationDuration =
  Duration(milliseconds: 300);

  // ---------------------------------------------------------------------------
  // Card Configuration
  // ---------------------------------------------------------------------------

  /// Border radius used for bottom information cards.
  static const double cardBorderRadius = 20.0;

  /// Elevation used by info cards.
  static const double cardElevation = 8.0;

  /// Standard padding for map overlay widgets.
  static const EdgeInsets overlayPadding =
  EdgeInsets.all(16.0);

  // ---------------------------------------------------------------------------
  // Speed Thresholds (km/h)
  // ---------------------------------------------------------------------------

  /// Approximate walking speed threshold.
  static const double walkingSpeedThreshold = 6.0;

  /// Approximate cycling speed threshold.
  static const double cyclingSpeedThreshold = 25.0;

  /// Approximate driving speed threshold.
  static const double drivingSpeedThreshold = 60.0;

  // ---------------------------------------------------------------------------
  // Status Colors
  // ---------------------------------------------------------------------------

  static const Color trackingColor = Colors.green;

  static const Color locatingColor = Colors.orange;

  static const Color errorColor = Colors.red;

  static const Color idleColor = Colors.grey;

  static const Color routeColor = Colors.blue;

  // ---------------------------------------------------------------------------
  // User Marker Colors
  // ---------------------------------------------------------------------------

  static const Color markerPrimaryColor = Colors.blue;

  static const Color markerBorderColor = Colors.white;

  static const Color markerAccuracyColor =
  Color(0x553F51B5);

  // ---------------------------------------------------------------------------
  // Geographic Defaults
  // ---------------------------------------------------------------------------

  /// Default location shown before GPS becomes available.
  ///
  /// Currently set to Dhaka, Bangladesh.
  static const double fallbackLatitude = 23.8103;

  static const double fallbackLongitude = 90.4125;

  // ---------------------------------------------------------------------------
  // Utility Methods
  // ---------------------------------------------------------------------------

  /// Determines whether a speed value (km/h)
  /// indicates that the user is moving.
  static bool isMoving(double speedKmH) {
    return speedKmH > 1.0;
  }

  /// Classifies movement type based on speed.
  static String movementType(double speedKmH) {
    if (speedKmH < walkingSpeedThreshold) {
      return 'Walking';
    }

    if (speedKmH < cyclingSpeedThreshold) {
      return 'Cycling';
    }

    if (speedKmH < drivingSpeedThreshold) {
      return 'Driving';
    }

    return 'Fast Travel';
  }
}