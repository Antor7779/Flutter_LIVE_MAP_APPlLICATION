/// Represents the current state of the location tracker.
enum TrackingStatus {
  /// Tracking has not started yet.
  idle,

  /// The app is requesting permissions,
  /// checking GPS availability, or obtaining
  /// the initial location fix.
  locating,

  /// Live tracking is active and location
  /// updates are being received successfully.
  tracking,

  /// The user denied location permission.
  permissionDenied,

  /// The device location service (GPS)
  /// is turned off.
  gpsDisabled,

  /// Tracking was manually stopped by the user.
  stopped,

  /// An unexpected error occurred.
  error,
}

/// Helper extensions for UI display and logic.
extension TrackingStatusExtension on TrackingStatus {
  /// User-friendly text representation.
  String get label {
    switch (this) {
      case TrackingStatus.idle:
        return 'Idle';

      case TrackingStatus.locating:
        return 'Locating...';

      case TrackingStatus.tracking:
        return 'Tracking';

      case TrackingStatus.permissionDenied:
        return 'Permission Denied';

      case TrackingStatus.gpsDisabled:
        return 'GPS Disabled';

      case TrackingStatus.stopped:
        return 'Stopped';

      case TrackingStatus.error:
        return 'Error';
    }
  }

  /// Indicates whether tracking is actively running.
  bool get isTracking {
    return this == TrackingStatus.tracking;
  }

  /// Indicates whether the tracker is trying
  /// to obtain the initial location.
  bool get isLocating {
    return this == TrackingStatus.locating;
  }

  /// Indicates whether the tracker encountered
  /// a blocking problem.
  bool get hasIssue {
    return this == TrackingStatus.permissionDenied ||
        this == TrackingStatus.gpsDisabled ||
        this == TrackingStatus.error;
  }

  /// Indicates whether the tracker can attempt
  /// to start or restart tracking.
  bool get canStart {
    return this == TrackingStatus.idle ||
        this == TrackingStatus.stopped ||
        this == TrackingStatus.error;
  }

  /// Indicates whether the tracker can be stopped.
  bool get canStop {
    return this == TrackingStatus.locating ||
        this == TrackingStatus.tracking;
  }
}