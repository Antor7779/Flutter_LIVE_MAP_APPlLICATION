import 'package:flutter/material.dart';

class RecenterButton extends StatelessWidget {
  /// Called when the user wants to recenter the map.
  final VoidCallback onPressed;

  /// Indicates whether auto-follow mode is enabled.
  final bool autoFollow;

  /// Whether to show the label next to the icon.
  final bool showLabel;

  const RecenterButton({
    super.key,
    required this.onPressed,
    required this.autoFollow,
    this.showLabel = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(28),
        child: InkWell(
          borderRadius: BorderRadius.circular(28),
          onTap: onPressed,
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: showLabel ? 16 : 14,
              vertical: 14,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedSwitcher(
                  duration:
                  const Duration(milliseconds: 250),
                  transitionBuilder:
                      (child, animation) {
                    return RotationTransition(
                      turns: animation,
                      child: FadeTransition(
                        opacity: animation,
                        child: child,
                      ),
                    );
                  },
                  child: Icon(
                    autoFollow
                        ? Icons.gps_fixed
                        : Icons.my_location,
                    key: ValueKey(autoFollow),
                    color: autoFollow
                        ? theme.colorScheme.primary
                        : theme.colorScheme.onSurface,
                  ),
                ),

                if (showLabel) ...[
                  const SizedBox(width: 10),

                  Text(
                    autoFollow
                        ? 'Following'
                        : 'Recenter',
                    style: theme.textTheme.labelLarge
                        ?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}